import React, { createContext, useContext, useState, useEffect } from 'react';

export type ThemeType = 'sakura' | 'lavender' | 'sage' | 'forest' | 'midnight';

interface ThemeContextType {
  theme: ThemeType;
  setTheme: (theme: ThemeType) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeType>(() => {
    const saved = localStorage.getItem('cute_theme');
    return (saved as ThemeType) || 'forest';
  });

  useEffect(() => {
    localStorage.setItem('cute_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
    
    // Set background color for the body based on theme for seamless experience
    const bgColors = {
      sakura: '#fffcfd',
      lavender: '#faf8ff',
      sage: '#f9fafb',
      forest: '#050705',
      midnight: '#0f0a0f'
    };
    document.body.style.backgroundColor = bgColors[theme];
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
