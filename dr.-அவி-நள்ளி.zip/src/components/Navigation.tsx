import React from 'react';
import { motion } from 'motion/react';
import { Home, Calendar, History } from 'lucide-react';
import { View } from '../types';

interface NavigationProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

export default function Navigation({ currentView, onNavigate }: NavigationProps) {
  const items = [
    { id: 'dashboard', icon: Home, label: 'சுழற்சி' },
    { id: 'tracker', icon: Calendar, label: 'பதிவு' },
    { id: 'trends', icon: History, label: 'வரலாறு' },
  ];

  return (
    <nav className="glass-nav rounded-[2.5rem] px-8 py-5 flex justify-between items-center relative overflow-hidden">
      {items.map(({ id, icon: Icon, label }) => {
        const isActive = currentView === id;
        return (
          <button
            key={id}
            onClick={() => onNavigate(id as View)}
            aria-label={label}
            className={`relative flex flex-col items-center gap-1 transition-all duration-500 tap-highlight-none ${
              isActive ? 'text-brand-primary scale-110' : 'text-brand-muted hover:text-brand-primary/60'
            }`}
          >
            <div className="relative z-10 transition-transform active:scale-90">
              <Icon size={24} strokeWidth={isActive ? 3 : 2} />
            </div>
            
            {isActive && (
              <motion.div 
                layoutId="navDot"
                className="absolute -bottom-2 w-2 h-2 bg-brand-primary rounded-full shadow-[0_0_10px_var(--shadow-color)]"
                transition={{ type: "spring", stiffness: 400, damping: 28 }}
              />
            )}
          </button>
        );
      })}
    </nav>
  );
}
