export interface SymptomLog {
  id: string;
  date: string;
  symptoms: string[];
  mood: string;
  painLevel: number; // 1-5
  notes: string;
  user?: string;
}

export type View = 'dashboard' | 'tracker' | 'trends';

export interface PCOSInfo {
  nextPeriod?: string;
  cycleDay?: number;
  currentUser?: string;
}
