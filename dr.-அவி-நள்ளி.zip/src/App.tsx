import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, User, Users, XCircle } from 'lucide-react';
import Navigation from './components/Navigation';
import Dashboard from './pages/Dashboard';
import Tracker from './pages/Tracker';
import Trends from './pages/Trends';
import { View, PCOSInfo, SymptomLog } from './types';
import { ThemeProvider } from './context/ThemeContext';

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

function AppContent() {
  const [loading, setLoading] = useState(true);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [logs, setLogs] = useState<SymptomLog[]>([]);
  const [profiles, setProfiles] = useState<string[]>(['Main User']);
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [showProfileSelector, setShowProfileSelector] = useState(false);
  const [newProfileName, setNewProfileName] = useState('');
  const [isEditMode, setIsEditMode] = useState(false);
  
  const [pcosInfo, setPcosInfo] = useState<PCOSInfo>({
    nextPeriod: '--',
    cycleDay: 0,
    currentUser: undefined
  });

  // Filter logs for calculation based on current user
  const userLogs = useMemo(() => {
    return logs.filter(l => l.user === currentUser);
  }, [logs, currentUser]);

  // Calculate info whenever user logs change
  useEffect(() => {
    if (userLogs.length > 0) {
      // Find the most recent period day (symptoms related to flow)
      const periodLogs = userLogs.filter(l => 
        l.symptoms.some(s => s.includes('ஓட்டம்'))
      ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      if (periodLogs.length > 0) {
        const lastPeriodDate = new Date(periodLogs[0].date);
        const today = new Date();
        const diffTime = Math.abs(today.getTime() - lastPeriodDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        // Simple 28 day cycle for prediction, but can be customized
        const cycleDay = (diffDays % 28) || 28;
        const daysToNext = 28 - cycleDay;
        const nextDate = new Date();
        nextDate.setDate(today.getDate() + daysToNext);

        setPcosInfo({
          nextPeriod: nextDate.toISOString().split('T')[0],
          cycleDay: cycleDay,
          currentUser: currentUser || undefined
        });
      } else {
        setPcosInfo({ nextPeriod: '--', cycleDay: 0, currentUser: currentUser || undefined });
      }
    } else {
      // Reset info if no logs (e.g. after clearing history)
      setPcosInfo({ nextPeriod: '--', cycleDay: 0, currentUser: currentUser || undefined });
    }
  }, [userLogs, currentUser]);

  // Load data once on component mount
  useEffect(() => {
    const savedLogs = localStorage.getItem('pcos_logs');
    const savedProfiles = localStorage.getItem('pcos_profiles');
    const savedLastUser = localStorage.getItem('pcos_last_user');
    
    if (savedLogs) {
      try { setLogs(JSON.parse(savedLogs)); } catch (e) { console.error(e); }
    }
    
    if (savedProfiles) {
      try { setProfiles(JSON.parse(savedProfiles)); } catch (e) { console.error(e); }
    }

    if (savedLastUser) {
      setCurrentUser(savedLastUser);
    } else {
      setShowProfileSelector(true);
    }

    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  // Persist data
  useEffect(() => {
    if (!loading) {
      localStorage.setItem('pcos_logs', JSON.stringify(logs));
      localStorage.setItem('pcos_profiles', JSON.stringify(profiles));
      if (currentUser) localStorage.setItem('pcos_last_user', currentUser);
    }
  }, [logs, profiles, currentUser, loading]);

  const handleAddProfile = () => {
    if (newProfileName.trim() && !profiles.includes(newProfileName.trim())) {
      const updated = [...profiles, newProfileName.trim()];
      setProfiles(updated);
      setNewProfileName('');
    }
  };

  const handleDeleteProfile = (name: string) => {
    const updatedProfiles = profiles.filter(p => p !== name);
    setProfiles(updatedProfiles);
    setLogs(logs.filter(l => l.user !== name));
    
    if (currentUser === name) {
      if (updatedProfiles.length > 0) {
        setCurrentUser(updatedProfiles[0]);
      } else {
        setCurrentUser(null);
        setShowProfileSelector(true);
      }
    }
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <Dashboard 
            info={pcosInfo} 
            onNavigate={setCurrentView} 
            logs={userLogs} 
            onSwitchUser={() => setShowProfileSelector(true)} 
          />
        );
      case 'tracker':
        return <Tracker onSave={(log) => setLogs([log, ...logs])} currentUser={currentUser || undefined} />;
      case 'trends':
        return (
          <Trends 
            logs={userLogs} 
            onClear={() => setLogs(logs.filter(l => l.user !== currentUser))} 
            currentUser={currentUser || undefined} 
          />
        );
      default:
        return (
          <Dashboard 
            info={pcosInfo} 
            onNavigate={setCurrentView} 
            logs={userLogs} 
            onSwitchUser={() => setShowProfileSelector(true)} 
          />
        );
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-[#020402] flex flex-col items-center justify-center z-[100] overflow-hidden px-4">
        {/* Medical Grid Overlay */}
        <div 
          className="absolute inset-0 opacity-[0.03] pointer-events-none" 
          style={{ 
            backgroundImage: `linear-gradient(var(--primary) 1px, transparent 1px), linear-gradient(90deg, var(--primary) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }} 
        />
        
        {/* Central Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-brand-primary/10 rounded-full blur-[120px] pointer-events-none" />
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center relative z-10 font-sans w-full max-w-sm"
        >
          {/* ECG / Heartbeat Animation */}
          <div className="relative w-full h-32 flex items-center justify-center mb-4">
            <svg width="250" height="80" viewBox="0 0 300 100" fill="none" className="drop-shadow-[0_0_15px_var(--primary)]">
              {/* Static Background Path */}
              <path 
                d="M0 50 L80 50 L85 40 L90 60 L95 20 L105 80 L110 50 L300 50" 
                stroke="var(--primary)" 
                strokeWidth="2" 
                className="opacity-20"
              />
              {/* Animating Core Path */}
              <motion.path
                d="M0 50 L80 50 L85 40 L90 60 L95 20 L105 80 L110 50 L300 50"
                stroke="var(--primary)"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ 
                  pathLength: [0, 1],
                  opacity: [0, 1, 1, 0],
                  pathOffset: [0, 1]
                }}
                transition={{ 
                  duration: 2.5, 
                  repeat: Infinity, 
                  ease: "easeInOut",
                  times: [0, 0.1, 0.9, 1]
                }}
              />
            </svg>
            
            {/* Pulsing Doctor Logo */}
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ 
                scale: [0.8, 1.1, 0.8],
                opacity: 1
              }}
              transition={{ repeat: Infinity, duration: 1.25, ease: "easeInOut" }}
              className="absolute text-6xl select-none pointer-events-none filter drop-shadow-[0_0_20px_var(--primary)]"
            >
              🩺
            </motion.div>
          </div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ 
              y: 0, 
              opacity: 1,
              scale: [1, 1.05, 1],
            }}
            transition={{ 
              delay: 0.3,
              scale: { repeat: Infinity, duration: 4, ease: "easeInOut" }
            }}
            className="text-center w-full px-4"
          >
            <motion.h2 
              animate={{ 
                filter: [
                  'drop-shadow(0 0 10px var(--primary))',
                  'drop-shadow(0 0 25px var(--primary))',
                  'drop-shadow(0 0 10px var(--primary))'
                ]
              }}
              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
              className="text-3xl sm:text-4xl font-black text-white tracking-tighter mb-2 break-words"
            >
              Dr. அவி நள்ளி
            </motion.h2>
            <div className="flex items-center justify-center gap-3">
              <div className="h-[1px] w-6 bg-brand-primary/30" />
              <p className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-muted">
                PCOS Care Expert
              </p>
              <div className="h-[1px] w-6 bg-brand-primary/30" />
            </div>
          </motion.div>

          {/* Loading Progress Bar */}
          <div className="mt-12 w-40 h-1 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              initial={{ x: "-100%" }}
              animate={{ x: "0%" }}
              transition={{ duration: 2.2, ease: "easeInOut" }}
              className="h-full w-full bg-brand-primary shadow-[0_0_10px_var(--primary)]"
            />
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen max-w-lg mx-auto bg-brand-bg relative overflow-x-hidden font-sans transition-colors duration-500 text-white">
      <AnimatePresence>
        {showProfileSelector && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-[#020402] flex flex-col items-center justify-center p-6 overflow-y-auto"
          >
            {/* Soft Ambient Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[600px] bg-brand-primary/5 rounded-full blur-[150px] pointer-events-none" />

            <motion.h1 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="text-2xl sm:text-3xl font-black mb-16 tracking-tight text-white relative z-10"
            >
              யார் பயன்படுத்துகிறார்கள்?
            </motion.h1>

            <button 
              onClick={() => setIsEditMode(!isEditMode)}
              className="absolute top-8 right-8 z-20 text-[10px] font-black uppercase tracking-widest text-[#5A5A40] border border-[#5A5A40]/30 px-4 py-2 rounded-full hover:bg-[#5A5A40]/10 transition-colors"
            >
              {isEditMode ? 'Done' : 'Edit'}
            </button>

            <div className="flex flex-wrap justify-center gap-6 sm:gap-10 mb-12 max-w-sm relative z-10">
              {profiles.map((p, i) => (
                <motion.div
                  key={p}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: i * 0.1 }}
                  className="flex flex-col items-center gap-4 group relative"
                >
                  <button
                    onClick={() => {
                      if (isEditMode) return;
                      setCurrentUser(p);
                      setShowProfileSelector(false);
                    }}
                    disabled={isEditMode}
                    className={`user-profile-circle bg-white/5 border border-white/10 transition-all duration-300 ${!isEditMode ? 'hover:bg-brand-primary/20 hover:border-brand-primary cursor-pointer' : 'opacity-50 grayscale'}`}
                  >
                    <span className="group-hover:scale-110 transition-transform text-white opacity-80 group-hover:opacity-100">
                      {p[0].toUpperCase()}
                    </span>
                  </button>

                  {isEditMode && profiles.length > 1 && (
                    <motion.button
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteProfile(p);
                      }}
                      className="absolute -top-2 -right-2 bg-brand-bg rounded-full text-red-500 hover:text-red-400 transition-colors"
                    >
                      <XCircle size={28} fill="currentColor" className="text-brand-bg" />
                    </motion.button>
                  )}

                  <span className="text-xs font-black uppercase tracking-widest text-brand-muted group-hover:text-white transition-colors">{p}</span>
                </motion.div>
              ))}
              
              <motion.button
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: profiles.length * 0.1 }}
                onClick={() => setNewProfileName(' ')}
                className="flex flex-col items-center gap-4 group"
              >
                <div className="user-profile-circle bg-white/5 border-2 border-dashed border-white/10 hover:border-white/30 transition-all">
                  <Plus size={40} className="text-white/20 group-hover:text-white/40 transition-colors" />
                </div>
                <span className="text-xs font-black uppercase tracking-widest text-brand-muted group-hover:text-white transition-colors">Add Profile</span>
              </motion.button>
            </div>

            {newProfileName !== '' && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-xs space-y-4 relative z-10"
              >
                <input 
                  autoFocus
                  placeholder="Profile Name..."
                  value={newProfileName === ' ' ? '' : newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddProfile()}
                  className="w-full bg-white/5 border-2 border-white/10 rounded-2xl py-4 px-6 text-white outline-none focus:border-brand-primary transition-all placeholder:text-white/20"
                />
                <div className="flex gap-2">
                   <button 
                    onClick={() => setNewProfileName('')}
                    className="flex-1 py-4 rounded-2xl bg-white/5 text-white font-black text-[10px] uppercase tracking-widest hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleAddProfile}
                    className="flex-1 py-4 rounded-2xl bg-brand-primary text-white font-black text-[10px] uppercase tracking-widest shadow-lg shadow-brand-primary/20"
                  >
                    Create
                  </button>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <main className="px-4 sm:px-6 pt-12 pb-36">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, scale: 0.98, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.98, y: -10 }}
            transition={{ type: "spring", stiffness: 350, damping: 30 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
      
      <div className="fixed bottom-8 left-0 right-0 px-6 z-50">
        <div className="max-w-md mx-auto">
          <Navigation 
            currentView={currentView} 
            onNavigate={setCurrentView} 
          />
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
