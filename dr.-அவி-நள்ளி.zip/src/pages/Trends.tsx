import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Calendar, Filter, ChevronRight, Hash, AlertCircle, Trash2, Download } from 'lucide-react';
import { SymptomLog } from '../types';
import { format, isWithinInterval, parseISO, startOfDay, endOfDay } from 'date-fns';
import * as XLSX from 'xlsx';

interface TrendsProps {
  logs: SymptomLog[];
  onClear: () => void;
  currentUser?: string;
}

export default function Trends({ logs, onClear, currentUser }: TrendsProps) {
  const [showConfirm, setShowConfirm] = useState(false);
  
  const downloadExcel = () => {
    if (logs.length === 0) return;
    
    const data = logs.map(log => ({
      'பயனர் (User)': log.user || 'Unknown',
      'தேதி (Date)': log.date,
      'மனநிலை (Mood)': log.mood,
      'அறிகுறிகள் (Symptoms)': log.symptoms.join(', '),
      'வலி அளவு (Pain Level)': log.painLevel,
      'குறிப்புகள் (Notes)': log.notes || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "PCOS History");
    
    // Generate buffer and download
    XLSX.writeFile(workbook, `PCOS_History_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);

  const filteredLogs = useMemo(() => {
    return logs
      .filter(log => log.date >= startDate && log.date <= endDate)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [logs, startDate, endDate]);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, scale: 0.95, y: 10 },
    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 25 } }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-8 pb-16 px-1"
    >
      <header className="text-center pt-4">
        <motion.p variants={item} className="text-brand-muted font-black text-[10px] uppercase tracking-[0.4em] mb-2">My History</motion.p>
        <motion.h1 variants={item} className="text-4xl font-black tracking-tight text-[var(--text-main)]">வரலாறு 🎀</motion.h1>
      </header>

      {/* Stats row */}
      <motion.div variants={item} className="grid grid-cols-2 gap-4">
        <div className="apple-card p-4 flex flex-col items-center justify-center text-center">
          <Hash className="text-brand-primary mb-2" size={20} />
          <span className="text-2xl font-black text-[var(--text-main)]">{logs.length}</span>
          <span className="text-[9px] font-black uppercase text-brand-muted tracking-widest">Total Entries</span>
        </div>
        <div className="apple-card p-4 flex flex-col items-center justify-center text-center">
          <Activity className="text-purple-400 mb-2" size={20} />
          <span className="text-2xl font-black text-[var(--text-main)]">{logs.length > 0 ? Math.max(...logs.map(l => l.painLevel)) : 0}</span>
          <span className="text-[9px] font-black uppercase text-purple-200 tracking-widest">Peak Pain</span>
        </div>
      </motion.div>

      {/* Download Action */}
      {logs.length > 0 && (
        <motion.div variants={item} className="px-1">
          <button 
            onClick={downloadExcel}
            className="w-full bg-brand-primary text-white py-4 rounded-[2rem] font-black uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3 shadow-lg shadow-brand-primary/20 active:scale-95 transition-all"
          >
            <Download size={18} />
            Download History (Excel)
          </button>
        </motion.div>
      )}

          {/* History List */}
      <motion.section variants={item} className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-brand-muted">
            {currentUser ? `${currentUser} - பதிவுகள்` : 'அனைத்து பதிவுகள்'}
          </h2>
          {logs.length > 0 && (
            <button 
              onClick={() => setShowConfirm(true)}
              className="px-4 py-2 rounded-full border border-red-500/30 text-red-500 text-[9px] font-black uppercase tracking-widest flex items-center gap-2 active:scale-95 transition-all"
            >
              <Trash2 size={12} />
              Clear All
            </button>
          )}
        </div>
        
        <AnimatePresence>
          {showConfirm && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="apple-card border-red-500/20 bg-red-500/5 mx-2"
            >
              <div className="flex flex-col items-center gap-4 py-4 text-center">
                <AlertCircle className="text-red-500" size={32} />
                <div className="space-y-1">
                  <h3 className="text-sm font-black text-white">இரத்த வரலாறு அழிக்கவா?</h3>
                  <p className="text-[10px] text-red-500/60 font-medium">இந்தச் செயலை மாற்ற முடியாது.</p>
                </div>
                <div className="flex gap-2 w-full max-w-[240px]">
                  <button 
                    onClick={() => setShowConfirm(false)}
                    className="flex-1 py-3 rounded-2xl bg-white/5 text-white text-[11px] font-black uppercase tracking-widest"
                  >
                    நிர்வாகம்
                  </button>
                  <button 
                    onClick={() => {
                      onClear();
                      setShowConfirm(false);
                    }}
                    className="flex-1 py-3 rounded-2xl bg-red-500 text-white text-[11px] font-black uppercase tracking-widest shadow-lg shadow-red-500/20"
                  >
                    அழி
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {logs.length > 0 ? logs.map((log) => (
              <motion.div 
                key={log.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="apple-card flex flex-col gap-5 relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/30 rounded-full -translate-y-12 translate-x-12 group-hover:scale-125 transition-transform duration-500" />
                
                <div className="flex justify-between items-start relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-brand-accent flex items-center justify-center text-brand-primary shadow-inner">
                      <Calendar size={18} />
                    </div>
                    <div>
                      <h3 className="text-base font-black text-[var(--text-main)] tracking-tight">
                        {new Date(log.date).toLocaleDateString('ta-IN', { weekday: 'short', day: 'numeric', month: 'short' })}
                      </h3>
                      <p className="text-[10px] font-black uppercase tracking-widest text-[#c7c7cc]">
                        {new Date(log.date).getFullYear()}
                      </p>
                    </div>
                  </div>
                  <span className="text-4xl filter drop-shadow-sm group-hover:scale-110 transition-transform">
                    {log.mood.split(' ')[0]}
                  </span>
                </div>

                <div className="flex flex-wrap gap-2 relative z-10">
                  {log.symptoms.map(s => (
                    <span key={s} className="px-3 py-1.5 bg-brand-card border border-brand-accent rounded-xl text-[11px] font-black text-brand-primary shadow-sm">
                      {s}
                    </span>
                  ))}
                </div>

                {log.notes && (
                  <div className="relative z-10 p-3 bg-brand-accent/20 rounded-2xl border border-brand-accent/30">
                    <p className="text-[11px] font-medium text-[var(--text-main)] italic leading-relaxed">
                      "{log.notes}"
                    </p>
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-brand-accent relative z-10">
                  <div className="flex items-center gap-2">
                    <AlertCircle size={14} className="text-brand-muted" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-[#c7c7cc]">வலி அளவு: {log.painLevel}</span>
                  </div>
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-1.5 h-1.5 rounded-full ${i < log.painLevel ? 'bg-brand-primary' : 'bg-brand-accent'}`}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            )) : (
              <div className="py-20 text-center flex flex-col items-center gap-4 opacity-30">
                <Activity size={48} className="text-brand-muted" />
                <p className="text-brand-muted font-bold text-sm uppercase tracking-widest leading-loose">
                  பதிவுகள் ஏதுமில்லை
                </p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </motion.section>
    </motion.div>
  );
}

