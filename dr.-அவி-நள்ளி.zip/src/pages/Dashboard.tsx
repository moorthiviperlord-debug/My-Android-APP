import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Droplets, Sparkles, Palette } from 'lucide-react';
import { View, PCOSInfo, SymptomLog } from '../types';
import { useTheme, ThemeType } from '../context/ThemeContext';

interface DashboardProps {
  info: PCOSInfo;
  onNavigate: (view: View) => void;
  logs: SymptomLog[];
  onSwitchUser: () => void;
}

export default function Dashboard({ info, onNavigate, logs, onSwitchUser }: DashboardProps) {
  const { theme, setTheme } = useTheme();
  const [showThemes, setShowThemes] = useState(false);

  const themeOptions: { id: ThemeType; label: string; color: string }[] = [
    { id: 'sakura', label: 'Pink', color: '#ec4899' },
    { id: 'lavender', label: 'Purple', color: '#8b5cf6' },
    { id: 'sage', label: 'Green', color: '#10b981' },
    { id: 'forest', label: 'Forest', color: '#064e3b' },
    { id: 'midnight', label: 'Dark', color: '#fb7185' }
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", stiffness: 300, damping: 28 }
    }
  };

  const today = new Intl.DateTimeFormat('ta-IN', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric' 
  }).format(new Date());

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-6 sm:space-y-10 pb-8 px-1"
    >
      <header className="flex flex-col items-center text-center pt-2 relative">
        <motion.div 
          variants={item}
          className="absolute left-2 top-0"
        >
          <button 
            onClick={onSwitchUser}
            className="w-10 h-10 rounded-full bg-white/50 border border-brand-primary/10 flex items-center justify-center text-brand-primary active:scale-95 transition-transform overflow-hidden"
          >
            <div className="w-full h-full bg-brand-primary text-white flex items-center justify-center font-black text-xs">
              {info.currentUser?.[0] || 'U'}
            </div>
          </button>
        </motion.div>

        <motion.div 
          variants={item}
          className="absolute right-2 top-0"
        >
          <button 
            onClick={() => setShowThemes(!showThemes)}
            className="w-10 h-10 rounded-full bg-white/50 border border-brand-primary/10 flex items-center justify-center text-brand-primary active:rotate-45 transition-transform"
          >
            <Palette size={20} />
          </button>
          
          <AnimatePresence>
            {showThemes && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.5, y: -20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.5, y: -20 }}
                className="absolute right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-pink-50 p-2 flex flex-col gap-2 z-50 min-w-[120px]"
              >
                {themeOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => {
                      setTheme(opt.id);
                      setShowThemes(false);
                    }}
                    className={`flex items-center gap-3 px-3 py-2 rounded-xl transition-colors ${theme === opt.id ? 'bg-pink-50' : 'hover:bg-gray-50'}`}
                  >
                    <div className="w-5 h-5 rounded-full" style={{ backgroundColor: opt.color }} />
                    <span className="text-[10px] font-black uppercase tracking-widest text-[#1c1c1e]">{opt.label}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        <motion.p 
          variants={item}
          className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-muted mb-1"
        >
          {info.currentUser ? `${info.currentUser}'s Cycle` : 'My Cute Cycle'}
        </motion.p>
        <motion.h1 
          variants={item}
          className="text-2xl sm:text-3xl font-black tracking-tight text-[var(--text-main)] px-2"
        >
          {today}
        </motion.h1>
      </header>

      {/* Primary Cycle Circle */}
      <motion.div 
        variants={item}
        className="flex justify-center py-2 sm:py-4"
      >
        <div className="relative w-64 h-64 min-[375px]:w-72 min-[375px]:h-72 sm:w-80 sm:h-80 flex items-center justify-center bg-brand-card rounded-full shadow-[0_30px_70px_var(--shadow-color)] border-[4px] sm:border-[6px] border-[var(--card-bg)] overflow-hidden animate-cute-float">
          <div className="absolute inset-3 sm:inset-4 rounded-full border-[8px] sm:border-[12px] border-brand-accent" />
          <motion.div 
            initial={{ rotate: -90, opacity: 0 }}
            animate={{ rotate: 90, opacity: 1 }}
            transition={{ delay: 0.5, duration: 1.5, ease: "circOut" }}
            className="absolute inset-3 sm:inset-4 rounded-full border-[8px] sm:border-[12px] border-transparent border-t-brand-primary drop-shadow-md" 
          />
          <div className="text-center z-10 scale-[0.85] min-[375px]:scale-90 sm:scale-100">
            <p className="text-brand-muted font-black text-[10px] sm:text-[11px] uppercase tracking-[0.3em] mb-0.5 sm:mb-1">Day</p>
            <div className="text-6xl min-[375px]:text-7xl sm:text-9xl font-black text-[var(--text-main)] tracking-tighter leading-none">
              {info.cycleDay || '--'}
            </div>
            <p className="text-brand-primary font-bold text-[10px] min-[375px]:text-[12px] sm:text-sm mt-2 min-[375px]:mt-3 sm:mt-4 bg-brand-accent px-2 min-[375px]:px-3 sm:px-4 py-1 rounded-full border border-brand-muted/20 whitespace-nowrap">
              {info.cycleDay === 0 ? 'பதிவு செய்யவும்' : info.cycleDay <= 7 ? 'Menstrual 🌸' : info.cycleDay <= 14 ? 'Follicular 🌿' : 'Luteal 💫'}
            </p>
          </div>
          
          {/* Decorative bits */}
          <Sparkles className="absolute top-8 right-8 sm:top-12 sm:right-12 text-brand-muted opacity-50" size={16} />
          <Droplets className="absolute bottom-8 left-8 sm:bottom-12 sm:left-12 text-brand-accent opacity-50" size={20} />
        </div>
      </motion.div>

      {/* Grid Metrics */}
      <div className="bento-grid">
        <motion.div 
          variants={item}
          className="apple-card flex flex-col justify-between h-32 xs:h-36 sm:h-44 group min-w-0"
        >
          <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-lg sm:rounded-2xl bg-brand-accent text-brand-primary flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform flex-shrink-0">
            <Droplets size={18} />
          </div>
          <div className="min-w-0">
            <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-brand-muted mb-0.5 sm:mb-1">Period இன்னும்</p>
            <p className="text-lg sm:text-3xl font-black text-[var(--text-main)] truncate leading-none">
              {info.cycleDay === 0 ? '--' : `${28 - (info.cycleDay % 28 || 28)} நாட்கள்`}
            </p>
          </div>
        </motion.div>
        
        <motion.div 
          variants={item}
          className="apple-card flex flex-col justify-between h-32 xs:h-36 sm:h-44 group min-w-0"
        >
          <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-lg sm:rounded-2xl bg-purple-50 text-purple-400 flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform flex-shrink-0">
            <Activity size={18} />
          </div>
          <div className="min-w-0">
            <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-brand-muted mb-0.5 sm:mb-1">அறிகுறிகள்</p>
            <p className="text-lg sm:text-2xl font-black text-[var(--text-main)] truncate leading-tight">
              {logs.length > 0 && logs[0].symptoms.length > 0 ? logs[0].symptoms[0] : 'ஏதுமில்லை'}
            </p>
          </div>
        </motion.div>
      </div>

      {/* Quick Entry Button */}
      <motion.div variants={item} className="pt-2">
        <button 
          onClick={() => onNavigate('tracker')}
          className="btn-forest w-full py-6 flex items-center justify-center gap-3 text-lg"
        >
          <span>இன்று பதிவு செய் 🎀</span>
        </button>
      </motion.div>
    </motion.div>
  );
}

