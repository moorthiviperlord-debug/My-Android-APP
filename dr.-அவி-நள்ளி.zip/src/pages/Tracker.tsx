import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Calendar as CalendarIcon, ChevronRight, Droplets } from 'lucide-react';
import { SymptomLog } from '../types';

interface TrackerProps {
  onSave: (log: SymptomLog) => void;
  currentUser?: string;
}

export default function Tracker({ onSave, currentUser }: TrackerProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [painLevel, setPainLevel] = useState(3);
  const [showSuccess, setShowSuccess] = useState(false);
  
  const flowTypes = [
    { id: '🌸 குறைவான ஓட்டம்', label: 'குறைவு' },
    { id: '🌺 மிதமான ஓட்டம்', label: 'மிதம்' },
    { id: '🌊 அதிக ஓட்டம்', label: 'அதிம்' }
  ];

  const symptoms = [
    '💥 வயிற்று வலி', '🎈 உப்பசம்', '✨ முகப்பரு', '🥚 கருமுட்டை வலி', 
    '💤 சோர்வு', '🤯 தலைவலி', '☁️ மார்பக மென்மை', '🤢 குமட்டல்'
  ];

  const moods = ['😊 மகிழ்ச்சி', '😌 அமைதி', '😔 கவலை', '😤 எரிச்சல்', '😴 சோர்வு'];
  const [notes, setNotes] = useState('');

  const toggleSymptom = (s: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]
    );
  };

  const handleSave = () => {
    onSave({
      id: Date.now().toString(),
      date: selectedDate,
      mood: selectedMood || '😊 மகிழ்ச்சி',
      symptoms: selectedSymptoms,
      painLevel,
      notes,
      user: currentUser
    });
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      setNotes('');
      setSelectedSymptoms([]);
      setSelectedMood(null);
      setPainLevel(3);
    }, 3000);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const item = {
    hidden: { opacity: 0, scale: 0.95, y: 10 },
    show: { 
      opacity: 1, 
      scale: 1, 
      y: 0, 
      transition: { type: "spring", stiffness: 300, damping: 25 } 
    }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-10 pb-12"
    >
      <header className="flex flex-col items-center text-center pt-4">
        <motion.p variants={item} className="text-[10px] font-black uppercase tracking-[0.3em] text-brand-muted mb-2">தினசரி பதிவு</motion.p>
        <motion.h1 variants={item} className="text-4xl font-black tracking-tight text-[var(--text-main)]">Daily Log 🎀</motion.h1>
      </header>

      {/* Date Picker */}
      <motion.section variants={item} className="apple-card space-y-4">
        <div className="flex items-center gap-3 text-brand-primary">
          <CalendarIcon size={18} />
          <h2 className="text-sm font-black uppercase tracking-[0.2em]">தேதி</h2>
        </div>
        <input 
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="w-full bg-brand-accent border-2 border-transparent focus:border-brand-muted/30 rounded-[1.5rem] py-4 px-6 text-base font-black tracking-tight text-[var(--text-main)] outline-none transition-all"
        />
      </motion.section>

      {/* Flow Selector */}
      <motion.section variants={item} className="apple-card space-y-6">
        <div className="flex items-center gap-3 text-brand-primary">
          <Droplets size={18} />
          <h2 className="text-sm font-black uppercase tracking-[0.2em]">இரத்த ஓட்டம்</h2>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {flowTypes.map((f) => {
            const isSelected = selectedSymptoms.includes(f.id);
            return (
              <button
                key={f.id}
                onClick={() => {
                  // Only one flow type at a time usually
                  setSelectedSymptoms(prev => {
                    const others = prev.filter(x => !flowTypes.some(ft => ft.id === x));
                    return isSelected ? others : [...others, f.id];
                  });
                }}
                className={`py-4 rounded-3xl text-xs font-black transition-all border-2 ${
                  isSelected 
                    ? 'bg-brand-primary border-brand-primary text-white shadow-lg' 
                    : 'bg-brand-card border-brand-accent text-brand-primary opacity-60'
                }`}
              >
                <div className="text-2xl mb-1">{f.id.split(' ')[0]}</div>
                <div>{f.label}</div>
              </button>
            );
          })}
        </div>
      </motion.section>

      {/* Mood Selector */}
      <motion.section variants={item} className="apple-card space-y-6">
        <div className="flex items-center gap-3 text-brand-primary">
          <ChevronRight size={18} className="rotate-90" />
          <h2 className="text-sm font-black uppercase tracking-[0.2em]">மனநிலை</h2>
        </div>
        <div className="flex justify-between items-center px-1">
          {moods.map((m) => {
            const isSelected = selectedMood === m;
            return (
              <button
                key={m}
                onClick={() => setSelectedMood(m)}
                className={`flex flex-col items-center gap-3 transition-all duration-500 tap-highlight-none ${
                    isSelected ? 'scale-125' : 'opacity-40 grayscale-[0.5] hover:opacity-70 scale-90'
                }`}
              >
                <span className="text-5xl drop-shadow-xl animate-cute-float" style={{ animationDelay: `${moods.indexOf(m) * 0.2}s` }}>
                  {m.split(' ')[0]}
                </span>
                <span className={`text-[9px] font-black uppercase tracking-widest ${isSelected ? 'text-brand-primary' : 'text-brand-muted'}`}>
                  {m.split(' ')[1]}
                </span>
              </button>
            );
          })}
        </div>
      </motion.section>

      {/* Symptoms Grid */}
      <motion.section variants={item} className="apple-card space-y-6">
        <div className="flex items-center gap-3 text-brand-primary">
          <Check size={18} />
          <h2 className="text-sm font-black uppercase tracking-[0.2em]">அறிகுறிகள்</h2>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {symptoms.map((s) => {
            const isSelected = selectedSymptoms.includes(s);
            return (
              <button
                key={s}
                onClick={() => toggleSymptom(s)}
                className={`py-3 px-2 min-h-[4rem] rounded-[1.5rem] text-[11px] sm:text-xs font-black tracking-tight leading-tight transition-all active:scale-95 border-2 flex items-center justify-center text-center ${
                  isSelected
                    ? 'bg-brand-primary border-brand-primary text-white shadow-lg shadow-brand-primary/20'
                    : 'bg-brand-card border-brand-accent text-brand-primary opacity-60 hover:opacity-100 hover:border-brand-primary/30'
                }`}
              >
                {s}
              </button>
            );
          })}
        </div>
      </motion.section>

      {/* Pain Level */}
      <motion.section variants={item} className="apple-card space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-brand-primary">
            <Check size={18} className="translate-y-[-1px]" />
            <h2 className="text-sm font-black uppercase tracking-[0.2em]">வலி அளவு</h2>
          </div>
          <span className="text-2xl font-black text-brand-primary bg-brand-accent w-10 h-10 flex items-center justify-center rounded-2xl">
            {painLevel}
          </span>
        </div>
        <input 
          type="range"
          min="1"
          max="5"
          step="1"
          value={painLevel}
          onChange={(e) => setPainLevel(parseInt(e.target.value))}
          className="w-full accent-brand-primary h-2 bg-brand-accent rounded-lg appearance-none cursor-pointer"
        />
        <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-brand-muted px-1">
          <span>குறைவு ☁️</span>
          <span>அதிகம் 🔥</span>
        </div>
      </motion.section>

      {/* Notes */}
      <motion.section variants={item} className="apple-card space-y-4">
        <div className="flex items-center gap-3 text-brand-primary">
          <Check size={18} />
          <h2 className="text-sm font-black uppercase tracking-[0.2em]">குறிப்புகள்</h2>
        </div>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="இன்று எப்படி உணர்கிறீர்கள்?..."
          className="w-full bg-brand-accent border-2 border-transparent focus:border-brand-muted/30 rounded-[1.5rem] py-4 px-6 text-base font-medium text-[var(--text-main)] outline-none transition-all min-h-[100px] resize-none"
        />
      </motion.section>

      {/* Action Button */}
      <div className="relative pt-4 px-1">
        <button 
          onClick={handleSave}
          className="btn-forest w-full text-xl py-6 flex items-center justify-center gap-3 relative"
        >
          Save Activity 💖
        </button>

        <AnimatePresence>
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="fixed bottom-32 left-1/2 -translate-x-1/2 bg-brand-card px-8 py-4 rounded-full shadow-2xl border border-brand-accent flex items-center gap-3 whitespace-nowrap z-[150] overflow-hidden"
            >
              <div className="absolute inset-0 bg-brand-accent/30 animate-pulse" />
              <Check className="text-brand-primary relative z-10" size={20} strokeWidth={3} />
              <span className="text-brand-primary font-black text-sm uppercase tracking-[0.2em] relative z-10">Saved Successfully ✨</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

